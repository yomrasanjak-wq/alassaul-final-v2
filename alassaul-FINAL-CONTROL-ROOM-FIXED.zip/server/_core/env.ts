export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: (process.env.BUILT_IN_FORGE_API_URL || process.env.FORGE_API_URL || process.env.GROQ_API_URL || "https://api.groq.com/openai/v1").trim(),
  forgeApiKey: (process.env.BUILT_IN_FORGE_API_KEY || process.env.GROQ_API_KEY || process.env.FORGE_API_KEY || "").trim(),
  googleTtsApiKey: (process.env.GOOGLE_TTS_API_KEY || "").trim(),
};
