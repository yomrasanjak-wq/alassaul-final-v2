
import React, { useMemo, useState, useEffect, useRef } from "react";
import { ExternalLink, MapPin, Search, X } from "lucide-react";

type MapCategory = "all" | "cities" | "nature" | "culture" | "family";
type MapDestination = { name: string; latin: string; category: Exclude<MapCategory, "all">; label: string; note: string; query: string; city: string; branch: string; position: { lat: number; lng: number }; };

const destinations: MapDestination[] = [
  { name: "طرابزون", city: "طرابزون", branch: "المدينة", latin: "Trabzon", category: "cities", label: "مدينة ساحلية", note: "بوابة البحر الأسود", query: "Trabzon", position: { lat: 41.0053, lng: 39.7225 } },
  { name: "أوزنجول", city: "طرابزون", branch: "طبيعة", latin: "Uzungol", category: "nature", label: "بحيرة", note: "بحيرة جبلية", query: "Uzungol", position: { lat: 40.6197, lng: 40.2958 } },
  { name: "ريزا", city: "ريزا", branch: "المدينة", latin: "Rize", category: "cities", label: "مدينة الشاي", note: "مزارع الشاي", query: "Rize", position: { lat: 41.0201, lng: 40.5234 } },
  { name: "أيدر", city: "ريزا", branch: "طبيعة", latin: "Ayder", category: "nature", label: "مرتفعات", note: "شلالات", query: "Ayder", position: { lat: 40.9527, lng: 41.0931 } },
  { name: "دير سوميلا", city: "طرابزون", branch: "تاريخ", latin: "Sumela", category: "culture", label: "تاريخ", note: "دير تاريخي", query: "Sumela", position: { lat: 40.6898, lng: 39.6585 } },
  { name: "أوردو", city: "أوردو", branch: "المدينة", latin: "Ordu", category: "cities", label: "ساحل", note: "واجهة بحرية", query: "Ordu", position: { lat: 40.9839, lng: 37.8764 } },
  { name: "إسطنبول", city: "إسطنبول", branch: "المدينة", latin: "Istanbul", category: "cities", label: "البوسفور", note: "البوسفور", query: "Istanbul", position: { lat: 41.0082, lng: 28.9784 } },
  { name: "أنقرة", city: "أنقرة", branch: "المدينة", latin: "Ankara", category: "cities", label: "عاصمة", note: "العاصمة", query: "Ankara", position: { lat: 39.9334, lng: 32.8597 } },
];

const filters = [{ key: "all", label: "كل الوجهات" }, { key: "cities", label: "مدن" }, { key: "nature", label: "طبيعة" }, { key: "culture", label: "تاريخ" }, { key: "family", label: "عائلية" }] as const;
const categoryColor: Record<MapDestination["category"], string> = { cities: "#d2ae62", nature: "#66a889", culture: "#b98b62", family: "#79a7b3" };

export function InteractiveNorthMap() {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<MapCategory>("all");
  const [selectedCity, setSelectedCity] = useState<string | null>("طرابزون");
  const [selected, setSelected] = useState<MapDestination | null>(null);
  const mapContainer = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);
  const [ready, setReady] = useState(false);
  const cityNames = ["طرابزون", "ريزا", "أوردو", "إسطنبول", "أنقرة"];

  const visible = useMemo(() => {
    const n = query.trim().toLowerCase();
    return destinations.filter(d => {
      const matchCity = !selectedCity || d.city === selectedCity;
      const matchFilter = filter === "all" || d.category === filter;
      const matchQuery = !n || `${d.name} ${d.latin}`.toLowerCase().includes(n);
      return matchCity && matchFilter && matchQuery;
    });
  }, [filter, query, selectedCity]);

  useEffect(() => {
    const load = async () => {
      if (!mapContainer.current) return;
      if (!document.querySelector('link[href*="leaflet"]')) {
        const link = document.createElement("link");
        link.rel = "stylesheet";
        link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
        document.head.appendChild(link);
      }
      const L = await new Promise<any>((res) => {
        if ((window as any).L) { res((window as any).L); return; }
        const s = document.createElement("script");
        s.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
        s.onload = () => res((window as any).L);
        document.head.appendChild(s);
      });
      if (mapRef.current) mapRef.current.remove();
      const map = L.map(mapContainer.current).setView([40.95, 39.25], 8);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "© OpenStreetMap | ALASSAUL", maxZoom: 18 }).addTo(map);
      mapRef.current = map;
      setReady(true);
    };
    load();
    return () => { if (mapRef.current) { mapRef.current.remove(); mapRef.current = null; } };
  }, []);

  useEffect(() => {
    if (!ready || !mapRef.current) return;
    const L = (window as any).L;
    markersRef.current.forEach((m: any) => m.remove());
    markersRef.current = [];
    visible.forEach((dest) => {
      const marker = L.circleMarker([dest.position.lat, dest.position.lng], { radius: 9, fillColor: categoryColor[dest.category], color: "#fff", weight: 2, fillOpacity: 0.9 }).addTo(mapRef.current);
      marker.bindPopup(`<b>${dest.name}</b><br/>${dest.label}`);
      marker.on("click", () => { setSelected(dest); mapRef.current.panTo([dest.position.lat, dest.position.lng]); mapRef.current.setZoom(11); });
      markersRef.current.push(marker);
    });
  }, [visible, ready]);

  return (
    <div className="north-map-experience bg-white rounded-2xl shadow-sm border overflow-hidden" dir="rtl">
      <div className="p-3 bg-[#f7f3e8] flex gap-2 items-center flex-wrap">
        <div className="flex items-center gap-1 bg-white rounded-full px-3 py-1.5 border flex-1 max-w-xs">
          <Search size={16} /><input value={query} onChange={e => setQuery(e.target.value)} placeholder="ابحث..." className="bg-transparent outline-none text-sm w-full" />{query && <button onClick={() => setQuery("")}><X size={14} /></button>}
        </div>
        <div className="flex gap-1">{filters.map(f => <button key={f.key} onClick={() => setFilter(f.key as any)} className={`px-3 py-1.5 rounded-full text-xs ${filter===f.key?"bg-[#2d5a3d] text-white":"bg-white border"}`}>{f.label}</button>)}</div>
      </div>
      <div className="p-2 flex gap-1.5 flex-wrap bg-[#fbfaf6] border-y">{cityNames.map(c => <button key={c} onClick={() => setSelectedCity(c)} className={`px-3 py-1 rounded-full text-sm ${selectedCity===c?"bg-[#d2ae62] text-white":"bg-white border"}`}>{c}</button>)}</div>
      <div className="flex flex-col lg:flex-row">
        <aside className="lg:w-[300px] max-h-[420px] overflow-y-auto p-2 bg-[#fbfaf6] border-l">
          <div className="text-xs text-gray-500 mb-2">{selectedCity} - {visible.length} وجهة</div>
          {visible.map((d,i) => <button key={d.name} onClick={() => { setSelected(d); mapRef.current?.panTo([d.position.lat, d.position.lng]); mapRef.current?.setZoom(11); }} className={`w-full text-right flex items-center gap-2 p-2.5 rounded-xl mb-1 border ${selected?.name===d.name?"bg-[#2d5a3d] text-white":"bg-white"}`}><span className="w-7 h-7 rounded-full flex items-center justify-center text-[10px] text-white" style={{background: categoryColor[d.category]}}>{String(i+1).padStart(2,"0")}</span><span className="flex-1 text-sm"><strong>{d.name}</strong></span><MapPin size={14} /></button>)}
        </aside>
        <div className="flex-1 relative"><div ref={mapContainer} className="w-full h-[420px] bg-[#e8efe6]" />{selected && <div className="absolute bottom-3 left-3 right-3 bg-white rounded-xl shadow-lg p-3 border flex justify-between items-center"><div><strong className="text-sm">{selected.name}</strong><br/><small className="text-xs text-gray-600">{selected.note}</small></div><a href={`https://www.google.com/maps/dir/?api=1&destination=${selected.position.lat},${selected.position.lng}`} target="_blank" className="bg-[#2d5a3d] text-white px-3 py-1.5 rounded-full text-xs flex gap-1"><ExternalLink size={12} /> اتجاهات</a></div>}</div>
      </div>
    </div>
  );
}
