
import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

interface MapViewProps {
  className?: string;
  initialCenter?: { lat: number; lng: number };
  initialZoom?: number;
  onMapReady?: (map: any) => void;
}

export function MapView({ className, initialCenter = { lat: 40.95, lng: 39.25 }, initialZoom = 8, onMapReady }: MapViewProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      if (!document.querySelector('link[href*="leaflet"]')) {
        const link = document.createElement("link");
        link.rel = "stylesheet";
        link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
        document.head.appendChild(link);
      }
      const L = await new Promise<any>((resolve, reject) => {
        if ((window as any).L) { resolve((window as any).L); return; }
        const s = document.createElement("script");
        s.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
        s.onload = () => resolve((window as any).L);
        s.onerror = reject;
        document.head.appendChild(s);
      });
      if (cancelled || !mapContainer.current) return;
      if (mapRef.current) mapRef.current.remove();
      const map = L.map(mapContainer.current).setView([initialCenter.lat, initialCenter.lng], initialZoom);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "&copy; OpenStreetMap | ALASSAUL",
        maxZoom: 18,
      }).addTo(map);
      mapRef.current = map;
      const compat = {
        _leaflet: map,
        panTo: (pos: any) => map.panTo([pos.lat ?? pos[0], pos.lng ?? pos[1]]),
        setZoom: (z: number) => map.setZoom(z),
      };
      setLoaded(true);
      onMapReady?.(compat);
    };
    load().catch(() => setLoaded(true));
    return () => { cancelled = true; if (mapRef.current) { mapRef.current.remove(); } };
  }, []);

  return (
    <div ref={mapContainer} className={cn("w-full h-[500px] rounded-xl overflow-hidden bg-[#e8efe6] relative", className)} style={{ minHeight: "500px" }}>
      {!loaded && <div className="absolute inset-0 flex items-center justify-center bg-[#f5f1e8] z-10"><div className="text-[#2d5a3d] font-bold animate-pulse">جاري تحميل خريطة الشمال التركي...</div></div>}
    </div>
  );
}
