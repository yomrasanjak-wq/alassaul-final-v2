import React, { useEffect, useRef, useState } from "react";
import { Pause, Volume2 } from "lucide-react";

type VoiceGender = "male" | "female";
type AssistantReplyProps = { text: string; language: "AR" | "TR" | "EN"; autoSpeak?: boolean; voiceGender?: VoiceGender; };
const speechLanguage: Record<AssistantReplyProps["language"], string> = { AR: "ar-SA", TR: "tr-TR", EN: "en-US" };

function cleanSpeechText(text: string) {
  return text.replace(/```[\s\S]*?```/g, "").replace(/[*_#`]/g, "").replace(/\[(.*?)\]\(.*?\)/g, "$1").replace(/\s+/g, " ").trim();
}
function splitIntoSentences(text: string): string[] {
  const cleaned = cleanSpeechText(text);
  if (!cleaned) return [];
  const parts = cleaned.split(/(?<=[.!?\u061F\u061B\u060C\n])\s+/);
  const chunks: string[] = [];
  let buffer = "";
  for (const p of parts) {
    if ((buffer + " " + p).length > 170) {
      if (buffer) chunks.push(buffer.trim());
      buffer = p;
    } else {
      buffer = buffer ? buffer + " " + p : p;
    }
  }
  if (buffer.trim()) chunks.push(buffer.trim());
  return chunks.filter(Boolean);
}
export function AssistantReply({ text, language, autoSpeak = true, voiceGender = "male" }: AssistantReplyProps) {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const queueRef = useRef<string[]>([]);
  const currentIndexRef = useRef(0);
  const genderRef = useRef(voiceGender);
  genderRef.current = voiceGender;
  const stopSpeaking = () => {
    if (typeof window !== "undefined" && window.speechSynthesis) window.speechSynthesis.cancel();
    queueRef.current = []; currentIndexRef.current = 0; setIsSpeaking(false);
  };
  const speakNext = () => {
    if (typeof window === "undefined") return;
    const synth = window.speechSynthesis;
    if (!synth) return;
    const q = queueRef.current;
    const idx = currentIndexRef.current;
    if (idx >= q.length) { setIsSpeaking(false); return; }
    const utter = new SpeechSynthesisUtterance(q[idx]);
    utter.lang = speechLanguage[language];
    utter.rate = language === "AR" ? 0.9 : 1;
    utter.pitch = genderRef.current === "male" ? 0.88 : 1.12;
    utter.volume = 1;
    utter.onend = () => { currentIndexRef.current++; speakNext(); };
    utter.onerror = () => { currentIndexRef.current++; speakNext(); };
    synth.speak(utter);
  };
  const speak = () => {
    if (typeof window === "undefined") return;
    const synth = window.speechSynthesis;
    if (!synth) return;
    synth.cancel();
    const sentences = splitIntoSentences(text);
    if (!sentences.length) return;
    queueRef.current = sentences;
    currentIndexRef.current = 0;
    setIsSpeaking(true);
    setTimeout(() => speakNext(), 200);
  };
  useEffect(() => {
    if (!autoSpeak || !text.trim()) return;
    const t = setTimeout(() => speak(), 350);
    return () => { clearTimeout(t); stopSpeaking(); };
  }, [text, language, autoSpeak, voiceGender]);
  return (
    <button className={`speak-button ${isSpeaking ? "is-speaking" : ""}`} onClick={isSpeaking ? stopSpeaking : speak} type="button">
      {isSpeaking ? <Pause size={13} /> : <Volume2 size={13} />}
      <small>{isSpeaking ? "إيقاف" : "استماع"}</small>
    </button>
  );
}
export type { VoiceGender };
