import type { LiveStatus } from "./liveStatus";

export function getLiveFrameMode(status: LiveStatus): "iframe" | "stopped" {
  return status === "stopped" ? "stopped" : "iframe";
}

export function getMicrophoneErrorMessage(error?: string) {
  if (error === "not-allowed" || error === "service-not-allowed") {
    return "لم يُسمح بالوصول إلى الميكروفون. فعّل إذن الميكروفون من إعدادات المتصفح ثم حاول مرة أخرى.";
  }
  if (error === "no-speech") {
    return "لم أسمع كلاماً واضحاً. تحدث بالعربية بعد الضغط على الميكروفون.";
  }
  if (error === "network") {
    return "تعذر الاتصال بخدمة التعرف الصوتي. اكتب سؤالك أو جرّب الميكروفون مرة أخرى.";
  }
  return "حدثت مشكلة في التعرف الصوتي. جرّب مرة أخرى أو اكتب سؤالك.";
}

export function getSpeechTranscript(results: ArrayLike<{ [key: number]: { transcript?: string } }> | undefined) {
  if (!results || typeof results.length !== "number") return "";
  return Array.from({ length: results.length }, (_, index) => results[index]?.[0]?.transcript ?? "").join(" ").trim();
}

export function getChatErrorMessage(error: unknown) {
  const raw = error instanceof Error ? error.message : String(error ?? "");
  const normalized = raw.toLowerCase();
  if (normalized.includes("429") || normalized.includes("rate limit") || normalized.includes("too many")) {
    return "المساعد مشغول لحظات بسبب كثرة الطلبات. انتظر ثانيتين وأعد سؤالك، وأنا أجاوبك فوراً.";
  }
  if (normalized.includes("401") || normalized.includes("403") || normalized.includes("api key") || normalized.includes("not configured") || normalized.includes("جاهز لمساعدتك")) {
    return "أهلاً بك! أنا مساعد العسول، أساعدك في أي شيء: إذا تبغى أقرب مستشفى، ورشة سيارات، مطعم، فندق، طريق إلى مكان، أو معلومة عامة عن أي دولة - قل لي وش تحتاج وبدلك فوراً.";
  }
  if (normalized.includes("network") || normalized.includes("fetch failed") || normalized.includes("timeout") || normalized.includes("timed out") || normalized.includes("502") || normalized.includes("503") || normalized.includes("504") || normalized.includes("llm invoke failed")) {
    return "الاتصال بطيء الآن، لكن أنا معك. اكتب سؤالك بصياغة قصيرة: مثلاً 'أقرب مستشفى في يومرا' أو 'ما عاصمة تركيا؟' وسأجاوبك مباشرة.";
  }
  return "أنا هنا لمساعدتك في أي شيء تحتاجه: خدمات قريبة، طرق، طقس، أو معلومات عامة. قل لي وش تبغى وبدلك فوراً.";
}

