
# طريقة النشر على Render.com - ALASSAUL-AI

هذه النسخة جاهزة 100% للنشر الكامل (Frontend + Backend)

### الخطوات:

1. ارفع هذا المجلد على GitHub (اعمل Repository جديد)
2. ادخل على https://dashboard.render.com
3. اضغط New + > Blueprint > واختر الريبو
4. Render راح يقرأ ملف render.yaml تلقائيا

### مهم جدا - قاعدة البيانات:
مشروعك يستخدم MySQL. لازم تضيف DATABASE_URL

في Render:
- روح Environment > Add Environment Variable
- KEY: DATABASE_URL
- VALUE: رابط قاعدة البيانات (مثال من PlanetScale او Aiven او TiDB)

مثال:
DATABASE_URL=mysql://user:password@host:3306/dbname

5. بعد ما تضيف DATABASE_URL، اضغط Deploy

### اذا ما عندك قاعدة بيانات:
انصحك تسوي حساب مجاني في:
- https://planetscale.com
- او https://aiven.io

### Build Command (لو ما استخدمت Docker):
Build: pnpm install && pnpm build
Start: pnpm start

### ملفاتي المضافة:
- Dockerfile: يشغل المشروع كامل
- render.yaml: اعدادات Render التلقائية
- .dockerignore
